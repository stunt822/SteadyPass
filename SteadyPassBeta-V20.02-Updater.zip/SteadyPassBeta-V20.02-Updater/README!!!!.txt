 (                                               (                      
 )\ )      )                  (                  )\ )                   
(()/(   ( /(     (       )    )\ )  (           (()/(      )            
 /(_))  )\())   ))\   ( /(   (()/(  )\ )         /(_))  ( /(   (    (   
(_))   (_))/   /((_)  )(_))   ((_))(()/(        (_))    )(_))  )\   )\  
/ __|  | |_   (_)_   (_))_    _| |  )(_))       | _ \  ((_)_  ((_) ((_) 
\__ \  |  _|  / -_)  / _` | / _` | | || |       |  _/  / _` | (_-< (_-< 
|___/   \__|  \___|  \__,_| \__,_|  \_, |       |_|    \__,_| /__/ /__/


UPDATE DIRECTIONS

WARNING: Do not Unplug or poweroff your board or computer from the usb port during the update. 
In some cases this may cause the Steady Pass system to be unrecoverable.

1. Plug in a USB cable to your Steady Pass System and connect 
   to a computer. Unplug any other "Arduino" device.

2. double click to run SteadyPassEZUpdate.bat

3. if drivers need to be installed, you may receive a prompt to give 
   permission for the update. Click Allow or OK if prompted.

4. The Steady Pass Updater will show Complete when it is finished.

5. Get back to the water!

6. If you receive an Error message instead of a Complete message, 
   please contact us at Steady Pass for Support. We will do our best to 
   resolve the issue as soon possible.
